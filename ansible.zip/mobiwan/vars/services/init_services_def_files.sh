#!/usr/bin/env bash

__FILES=$(ls | grep yml)
__LISTEN_PORT=9001
__BASE_JUMP=2
__JVM_MIN=-Xms1g
__JVM_MAX=-Xmx3g
__INFRA_SERVICES="gateway config eureka monitoring dashboard"
__GIT_AUTH_FILE="./__GIT_SERVER_AUTH__"

for __FILE in ${__FILES}; do
	__BASE_NAME=$(echo ${__FILE} | sed -e 's/\.yml$//g')
        __LISTEN_PORT=$(expr ${__LISTEN_PORT} + ${__BASE_JUMP})
        sed -e "s/__SERVICE_NAME__/"${__BASE_NAME}"/g" -e "s/__JVM_MIN__/"${__JVM_MIN}"/g" -e "s/__JVM_MAX__/"${__JVM_MAX}"/g"  -e "s/__LISTEN_PORT__/"${__LISTEN_PORT}"/g" __template_def_services__ > ${__FILE}
        echo [ CONF ] - Service name ${__BASE_NAME}
done

#
for __FILE in ${__INFRA_SERVICES}; do
        sed -i -e "s/"${__JVM_MIN}"//g" -e "s/"${__JVM_MAX}"//g" -e "/Environment:/d" -e "/\- port=/d" ${__FILE}.yml
done

cat ${__GIT_AUTH_FILE} >> config.yml
