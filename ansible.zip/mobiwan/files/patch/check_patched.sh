#!/usr/bin/env bash


__SOURCE_DIR=./workspaces
__TARGET_DIR=../arch
__JARS_LIST=$(ls ${__SOURCE_DIR} | grep '.jar')
__JARS_COUNT=$(echo ${__JARS_LIST} | wc -w)
__MD5SUM=$(which md5sum)
__MATCHING_ERRORS=0
__NO_EXISTING_ERROR=0

echo ""
echo -e "\e[93mO_o\e[0m"
echo -e "    \e[93m**\e[0m The script will compare all JARS file in ${__SOURCE_DIR}"
echo -e "       with the corresponding files in ${__TARGET_DIR}"
echo -e "    \e[93m**\e[0m Go to compare ${__JARS_COUNT} file(s)"
echo ""

sleep 2

for svc in ${__JARS_LIST}; do
    __SOURCE_MD5=$(${__MD5SUM} ${__SOURCE_DIR}/${svc} | awk '{print $1}')
    __TARGET_MD5=$(${__MD5SUM} ${__TARGET_DIR}/${svc} | awk '{print $1}')
    echo -n "SOURCE: ${__SOURCE_MD5}  --  TARGET: ${__TARGET_MD5}  --  ${svc} "
    if [ -f ${__SOURCE_DIR}/${svc} ] && [ -f ${__TARGET_DIR}/${svc} ]; then
        if [ ${__SOURCE_MD5} == ${__TARGET_MD5} ]; then
            echo -e " \e[92m MATCH \e[0m"
        else
            echo -e " \e[93m NO MATCH \e[0m"
            __MATCHING_ERRORS=$(expr ${__MATCHING_ERRORS} + 1)
        fi
    else
        echo -e " \e[91m ERROR OCCURED SOMEWHERE \e[0m"
        __NO_EXISTING_ERROR=$(expr ${__NO_EXISTING_ERROR} + 1)
    fi
done

echo ""
if [ ${__NO_EXISTING_ERROR} -eq 0 ] && [ ${__MATCHING_ERRORS} -eq 0 ]; then
    echo -e " \e[92mDone success.\e[0m"
    echo -e "  \e[93m**\e[0m It sounds that all files are identical."
fi

if [ ${__MATCHING_ERRORS} -gt 0 ]; then
    echo -e " \e[93mMATCHING ERROR:\e[0m"
    echo -e "  \e[93m**\e[0m Some files are not matching \e[91mCAUTION\e[0m"
fi

if [ ${__NO_EXISTING_ERROR} -gt 0 ]; then
    echo -e " \e[91mFILE ABSENT:\e[0m"
    echo -e "  \e[93m**\e[0m Some file that exist in the workspace directory ${__SOURCE_DIR} doest exist in the target directory ${__TARGET_DIR}"
fi

