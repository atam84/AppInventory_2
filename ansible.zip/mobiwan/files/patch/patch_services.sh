#!/usr/bin/env bash

#
# Author: Mohamed Amine TAMDY
# Date: 02/07/2019
# Version: 0.2
# 02/07/2019 : Add SSL certificate to the internal JKS loaded by the JAR "BOOT-INF/classes/ssl/banking.jks"
#              If the JKS name change the variable __JAR_JKS_NAME should be changed too
#              If the default password "changeit" change too the variable __JKS_STORE_PASS should be changed to follow
#
# 04/07/2019 : Operate modification on the logback file parameters to follow the rigth loggin path
#              The modification is performed in "/BOOT-INF/classes/logback-spring.xml" to set the rigth value between balize <fileNamePattern>.*</fileNamePattern>
#              and put the rigth log path like "/data/logs/<SERVICE_NAME>-services/<SERVICE_NAME>_%d{yyyy-MM-dd}.%i.log"
#
#

__MAIN_DIR=$(pwd)
__JARS_DIR=./jars
__JARS_LIST=$(ls ${__JARS_DIR})
__WORKING_DIR=./workspaces
__CERTS_DIR=./certs
__CERTS_FILES=$(ls ${__CERTS_DIR}/)
__ZIP_CMD=$(which zip)
__UNZIP_CMD=$(which unzip)
__JAVA_KEYTOOL=$(which keytool)
__SED_CMD=$(which sed)
__RM_CMD=$(which rm)
__GREP_CMD=$(which grep)
__JAR_JKS_NAME=banking.jks
__JKS_STORE_PASS=changeit
__MD5SUM=$(which md5sum)
__OUTPUT_DIR=${__MAIN_DIR}/../arch


echo ""
echo -e "\e[92mO_o\e[0m \e[93mINFO\e[0m :"
echo -e "\e[93m**********\e[0m"
echo "    ** Main dir           : ${__MAIN_DIR}"
echo "    ** Output dir         : ${__OUTPUT_DIR}"
echo "    ** Jars dir           : ${__JARS_DIR}"
echo "    ** Working dir        : ${__WORKING_DIR}"
echo "    ** Certificate dir    : ${__CERTS_DIR}"
echo "    ** Certificate list   : ${__CERTS_FILES}"
echo "    ** Zip command        : ${__ZIP_CMD}"
echo "    ** UnZip command      : ${__UNZIP_CMD}"
echo "    ** Keytool command    : ${__JAVA_KEYTOOL}"
echo "    ** JKS file name      : ${__JAR_JKS_NAME}"
echo "    ** JKS Store password : ${__JKS_STORE_PASS}"
echo -e "\e[93m**********\e[0m"
echo ""
echo -e "^^^"
echo -e "O_o"
echo ""
echo -e "\e[91mUSE CTRL+C TO ABORT AT ANY TIME AND AT YOUR OWN RISQUE\e[0m"
echo -n "** Start patching services in 10 seconds "


trap ctrl_c INT

function ctrl_c {
    echo -e "\n\n\e[91m** \e[93mCTRL+C\e[0m actived by the user"
    echo -e "\e[91mexit the program\e[0m"
    exit
}

function print_status {
    __ERROR=$?
    if [ ${__ERROR} -eq 0 ]; then
        echo -e " [ \e[92mOK\e[0m ]"
    else
        echo -e " [ \e[91mFAIL\e[0m ]"
    fi
}

for i in `seq 1 10`; do
    sleep 1
    echo -e -n "\e[92m${i}\e[0m.. "
done

echo ""
echo ""
echo -n "** Cleanup the working space : ${__WORKING_DIR}  "
${__RM_CMD} -rf ${__WORKING_DIR}/* 2>&1 >/dev/null
print_status $?

for svc in $(ls ${__JARS_DIR}); do
    __SRV_NAME=$(echo ${svc} | awk -F. '{print $1}')
    echo -e "\e[93m-- O_o ** \e[0m Operate patch for service: \e[93m ${__SRV_NAME} \e[0m"
    echo -n "    ** Copy the archive to the working space : ${__WORKING_DIR}/${svc}"
    cp ${__JARS_DIR}/${svc} ${__WORKING_DIR}/
    print_status $?
    echo -n "    ** Create extract directory : ${__WORKING_DIR}/${__SRV_NAME}"
    mkdir -p ${__WORKING_DIR}/${__SRV_NAME}
    print_status $?
    echo -n "    ** Unzip the archive file ${__WORKING_DIR}/${svc}"
    ${__UNZIP_CMD} ${__WORKING_DIR}/${svc} -d ${__WORKING_DIR}/${__SRV_NAME} 2>&1 > /dev/null
    print_status $?
    echo "    ** Apply patchs if the archive is patchable : "
    # Add certificate
    echo -e "    \e[95m-<O_o>- \e[93mAdd certificates \e[0m"
    if [ -d ${__WORKING_DIR}/${__SRV_NAME}/BOOT-INF/classes/ssl ]; then
        echo -n "    ** Put the Certs in the ssl directory "
        cp -f ${__CERTS_DIR}/* ${__WORKING_DIR}/${__SRV_NAME}/BOOT-INF/classes/ssl/
        print_status $?
        echo -n "    ** Change to ssl JKS directory "
        cd ${__WORKING_DIR}/${__SRV_NAME}/BOOT-INF/classes/ssl/
        print_status $?
        for cert in ${__CERTS_FILES}; do
            __ALIAS=$(echo ${cert} | awk -F. '{print $1}')
            echo -n "    ** Import certificate ${cert} to the JKS file ${__JAR_JKS_NAME}"
            ${__JAVA_KEYTOOL} -importcert -alias ${__ALIAS} -file ${cert} -keystore ${__JAR_JKS_NAME} -storepass ${__JKS_STORE_PASS} -noprompt 2>&1 >/dev/null
            print_status $?
        done
        echo -n "    ** Change to the working directory at the working space for ${__SRV_NAME}"
        cd ${__MAIN_DIR}/${__WORKING_DIR}/${__SRV_NAME}
        print_status $?
        echo -n "    ** Patch the Jar file ${svc} "
        ${__ZIP_CMD} ../${svc} BOOT-INF/classes/ssl/${__JAR_JKS_NAME} 2>&1 >/dev/null
        print_status $?
    fi
    sleep 1
    # Modify the log path
    cd ${__MAIN_DIR}
    echo -e "    \e[95m-<o_O>- \e[93mModify the log path \e[0m"
    if [ -f ${__WORKING_DIR}/${__SRV_NAME}/BOOT-INF/classes/logback-spring.xml ]; then
        echo -n "    ** Patch of logback-pring.xml "
        echo -n "    ** Go to ${__SRV_NAME}/BOOT-INF/classes/ "
        cd ${__WORKING_DIR}/${__SRV_NAME}/BOOT-INF/classes/
        print_status $?

	echo -n "Check old value: \n"
	grep fileNamePattern logback-spring.xml
        echo -n "    ** Apply change: /data/logs/${__SRV_NAME}-services/${__SRV_NAME}_%d{yyyy-MM-dd}.%i.log  "
        ${__SED_CMD} -i -e 's/<fileNamePattern>.*<\/fileNamePattern>/<fileNamePattern>\/data\/logs\/'${__SRV_NAME}'-services\/'${__SRV_NAME}'_%d{yyyy-MM-dd}.%i.log<\/fileNamePattern>/g' logback-spring.xml
        print_status $?
        cd ${__MAIN_DIR}/${__WORKING_DIR}/${__SRV_NAME}
        echo -n "    ** Patch the Jar file ${svc} "
        ${__ZIP_CMD} ../${svc} BOOT-INF/classes/logback-spring.xml 2>&1 >/dev/null
        print_status $?
    fi
    # Copy patched archive to the output directory
    echo -n "    ** Copy patched file to the output directory ${__OUTPUT_DIR}/${svc} "
    cp -f ${__MAIN_DIR}/${__WORKING_DIR}/${svc} ${__OUTPUT_DIR}/${svc}
    print_status $?
    echo -n "    ** Cleanup the working space but keep the patched archives"
    rm -rf ${__MAIN_DIR}/${__WORKING_DIR}/${__SRV_NAME}
    print_status $?

    # Don't remove archives in working space
    #echo -n "    ** Remove archive file  "
    #rm ${__MAIN_DIR}/${__WORKING_DIR}/${svc}
    #print_status $?
    echo ""
    echo -e "\e[93m-- o_O ** \e[0mDONE."
    echo ""
    cd ${__MAIN_DIR}
    sleep 1
done

echo -e "\e[93m** \e[0m"
echo -e "\e[91mFYI:\e[0m\n The patched archives that exist in the workspace will be destroyed at the next execution of this script"
echo -e "\e[93m** \e[0m"

for svc in ${__JARS_LIST}; do
    __OLD_MD5=$(${__MD5SUM} ${__JARS_DIR}/${svc} | awk '{print $1}')
    __NEW_MD5=$(${__MD5SUM} ${__OUTPUT_DIR}/${svc} | awk '{print $1}')
    echo -n "OLD: ${__OLD_MD5}  --  NEW: ${__NEW_MD5}  --  ${svc} "
    if [ -f ${__JARS_DIR}/${svc} ] && [ -f ${__OUTPUT_DIR}/${svc} ]; then
        if [ ${__OLD_MD5} == ${__NEW_MD5} ]; then
            echo -e " \e[93m NO CHANGE \e[0m"
        else
            echo -e " \e[92m PATCHED \e[0m"
        fi
    else
        echo -e " \e[91m ERROR OCCURED SOMEWHERE \e[0m"
    fi
done


